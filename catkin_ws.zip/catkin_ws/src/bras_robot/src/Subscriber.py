#!/usr/bin/env python3

import rospy
import math
from std_msgs.msg import String
from bras_robot.msg import Position

SHOULDERPFFSET = 0 #142.0 
ELBOWOFFSET = 0 #45.0
Al = 0.182
Au = 0.188
L2 = 0.073
Lo = 0.047
L1o = 0 #0.040
Zo = 0 #-0.070
K = 1 #5.1


def FWKinematic(x, y, z, thetaMB, thetaME, thetaMS):
	theta1 = thetaMB * (1 / K)
	theta2 = (thetaME - thetaMS) * (1 / K) + ELBOWOFFSET
	theta3 = thetaMS * (1 / K) + SHOULDEROFFSET
	
	theta1 = theta1 * (math.pi / 180.0)
	theta2 = theta2 * (math.pi / 180.0)
	theta3 = theta3 * (math.pi / 180.0)

	z = L2 + math.sin(theta2) * Al - math.cos(theta3 - (90 - theta2)) * Au + Zo
	k1 = math.sin(theta3 - (90 - theta2)) * Au + math.cos(theta2) * Al + Lo + L1o

	x = math.cos(theta1) * k1
	y = math.sin(theta1) * k1

	return x, y, z


def InvKinematic(theta1, theta2, theta3, x, y, z):
	# x = x - math.cos(theta1) * L1o
	# ly = y - math.sin(theta1) * L1o
	z = z - Zo - L2


	theta1 = math.atan2(y, x)
	
	L1 = math.sqrt(x**2 + y**2) - Lo
	L7 = math.sqrt(L1**2 + z**2)

	a = z / L7
	b = (L7**2 + Al**2 - Au**2) / (2 * L7 * Al)
	c = (Al**2 + Au**2 - L7**2) / (2 * Al * Au)


	theta2 = (math.atan2(a, math.sqrt(1 - a**2)) + math.atan2(math.sqrt(1 - b**2), b))
	theta3 = math.atan2(math.sqrt(1 - c**2), c)

	
	theta1 = theta1 * 180 / math.pi
	theta2 = (theta2 - ELBOWOFFSET) * 180 / math.pi
	theta3 = (theta3 - ELBOWOFFSET) * 180 / math.pi

	return theta1, theta2, theta3

	thetaMB = theta1 * K
	thetaME = (theta2 + theta3) * K
	thetaMS = theta3 * K

	return thetaMB, thetaME, thetaMS


def callback(data):
	rospy.loginfo(f'{data.message}, X : {data.x} Y : {data.y} Z : {data.z}')
	
	coord_x = data.x
	coord_y = data.y
	coord_z = data.z

	theta1, theta2, theta3 = InvKinematic(0, 0, 0, coord_x, coord_y, coord_z)

	rospy.loginfo(f'theta_1 : {theta1} theta_2 : {theta2} theta_3 : {theta3}')
	
def listener():
	rospy.init_node('listener_coord')
	rospy.Subscriber("chatter_coord", Position, callback)
	rospy.spin()

if __name__ == '__main__':
	listener()
