#!/usr/bin/env python3

import rospy
from std_msgs.msg import String
from bras_robot.msg import Position


def publisher():
	pub = rospy.Publisher('chatter_coord', Position, queue_size=10)
	rospy.init_node('talk_coord')
	r = rospy.Rate(10)
	while not rospy.is_shutdown():
		
		msg = Position()
		msg.message = "Bonjour"
		msg.x = float(input('Saisir X :'))
		msg.y = float(input('saisir Y :'))
		msg.z = float(input('Saisir Z :'))
		pub.publish(msg)
		r.sleep()


if __name__ == '__main__':
	publisher()
