#!/usr/bin/env python3


import socket

hote = "localhost"
port = 15555

socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
socket.connect((hote, port))
print(f"Connection on {port}")
while True:
	exemple_message = input("saisir message :")
	socket.send(exemple.encode())
	print("close")
socket.close()
