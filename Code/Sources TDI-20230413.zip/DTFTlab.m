%=========================================================================
% [Nu,S] = DTFTlab(Signal)
% Estimation de la TFTD d'un Signal
%
% Parametre d'appel :
%  - Signal  : vecteur(s) ligne(s) contenant la(les) sequence(s)
%              temporelle(s), les echantillons sont distribues selon la (les) 
%              colonne(s)
% Parametres renvoyes :
%  - S : vecteur (matrice) TFTD ligne(s) de Signal
%  - Nu : vecteur frequence normalisee ligne
%=========================================================================
% V6.0 - mars 2017 - Michel Corneloup, Nicolas Simond

function [Nu,S] = DTFTlab (Signal)

[lig,col] = size(Signal);   % forcage en vecteurs colonnes
if(lig > col)
    Signal = Signal.';
    [lig,col] = size(Signal);
end;

% Zero padding
n = nextpow2(col);
if (n <= 13)	
	n = n + 2;	
end;
ordre   = 2^n;
fen     = 2*hanning(col).';

% estimation de la TFTD
Nu	= (0:ordre-1)/ordre;
S   = fft((Signal.*(ones(lig,1)*fen)).', ordre).';


