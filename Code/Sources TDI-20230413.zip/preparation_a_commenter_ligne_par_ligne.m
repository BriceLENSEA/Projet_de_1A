% Ajouter vos commentaires à la suite de chaque instruction pour détailler son effet.
% Les commentaires commencent après le symbole '%' et finissent pas un retour à la ligne.

%% Les variables
X = [ 1+j 2-j ; 3-2j 4 ]
Xalt = [ 1+j, 2-j; 3-2j, 4]
X1 = [1 + 2 3]
X2 = [1 +2 3]
Y = 3:0.3:5
Z = 5:-0.3:3
N = 0:9
A = zeros(2,3)
B = ones(3,2)
C = eye(2,3)
D = randn(3,2)

%% Variables prédéfinies
pi
eps
2^(-52)
i
ans
pi=2
clear pi

%% Types et noms des variables
temp = 37.2
% Seuils_temp = Temp +[-1,1]
% /!\ l'exécution de la ligne précédente (commentée) produit une erreur car la
% variable 'Temp' n'existe pas. Par contre 'temp' existe et la valeur 37,2 y est
% affectée. Décommenter pour voir l'erreur.

%% La manipulation et extraction de (sous-)matrices
M1 = ones(4,6)
M2 = 2 * M1
M1(3,4) = M2(1,2)
MRand = randn(3,3)
Vy = MRand(:,2)
Vx = MRand(3,:)
t=Vy(2)
Abs = 10 : 20
Ord = Abs(11:-1:1)
Ind = 1:2:8
Ord (Ind) = 0
MRand = randn (4,4)
Ma = MRand( : , [3,1,2])
C1 = [ Abs , Ord]
C2 = [ Abs ; Ord]
s1 = size(Ma)
nl = numel(Ma)
s2 = size(Ma(1,:))
l = length(Ma(:,2))
X = 10 : 20
[X (length(X) - 1) , X(end - 1)]
Abs(Ind) = [ ]

%% Le formatage des valeurs numériques
rect = @(x) abs(x) < 0.5 ;
tri = @(t) (1-abs(t)).*rect(t);
rect(-3:3)
tri(-3:.5:3)

%% L'aide en ligne
help plot
doc step

%% Les opérateurs arithmétiques
(2+3*j)'
3*exp(j*pi/4).'
D = diag([3,5,4])
E = D + 3
Ealt = D + 3*ones(3,3)

%% Les opérateurs logiques
MId = eye(3)
MId(MId ~= 1) = 2
MC = randn(3,3)
MC(MC < 0) = 0

%% Le calcul vectoriel
X1 = rand(1,100000);
X2 = rand(1,100000);
c1 = 0;
% option 1
tic
for k=1 : length(X1)
	c1 = c1+X1(k)*X2(k);
end
t1 = toc;
%option 2
tic;
c2 = X1*X2.';
t2 = toc;
% comparaison
t1/t2
abs((c1-c2)/c1)

%% La représentation graphique des variables
N = 0:49; nu0 = 0.05; Y = sin(2*pi*nu0*N); figure(3); stem(Y);

N1 = 0 : 99; N2 = 0 : 4 : 99;
S1 = sin(2*pi*0.02*N1); S2 = sin(2*pi*0.02*N2);
figure(2);
hold on;
plot (N1, S1,'r', N1, S1, 'r*');
stairs(N2,S2,'b');
hold off;

figure;
subplot (211);
plot (N2,S2,'m', N1,S1,'ks');
subplot (212);
stem (N2,S2,'m');

close all;
figure(4);
subplot(311);
plot (N1, sin(2*pi*0.02*N1), 'rs');
subplot(312);
stem(N1(30:40), S1(30:40), 'gd');
subplot(313);
stem(N1, S1, 'squarey');
A = axis;
A(1:2) = [30,40];
axis(A);

disp('preparation executee');

